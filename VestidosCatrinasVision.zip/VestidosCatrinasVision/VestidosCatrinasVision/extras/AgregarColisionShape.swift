//
//  AgregarColisionShape.swift
//  VestidosCatrinasVision
//
//  Created by Jadzia Gallegos on 28/10/24.
//

import Foundation
import RealityKit

extension ModelEntity{
}
