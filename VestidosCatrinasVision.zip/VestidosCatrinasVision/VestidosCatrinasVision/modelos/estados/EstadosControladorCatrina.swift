//
//  EstadosControladorCatrina.swift
//  VestidosCatrinasVision
//
//  Created by Jadzia Gallegos on 20/10/24.
//


enum EstadosControladorCatrina{
    case iniciando_carga
    case carga_finalizada
    case espacio_abierto
    case espacio_cerrado
}
